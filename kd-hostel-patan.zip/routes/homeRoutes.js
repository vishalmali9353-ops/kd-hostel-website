const express = require("express");
const router = express.Router();
const { getHomeOverview } = require("../controllers/homeController");

// Public route - shown on the hostel home page, no login required
router.get("/", getHomeOverview);

module.exports = router;
