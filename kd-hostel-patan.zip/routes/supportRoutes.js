const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const { protectStudent } = require("../middleware/studentAuthMiddleware");
const { createTicket, getTickets, getMyTickets, respondTicket } = require("../controllers/supportController");

router.post("/", protectStudent, createTicket);
router.get("/my", protectStudent, getMyTickets);
router.get("/", protect, getTickets);
router.put("/:id", protect, respondTicket);

module.exports = router;
