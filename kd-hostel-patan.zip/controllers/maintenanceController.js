const MaintenanceRequest = require("../models/MaintenanceRequest");

// @desc  Log a new maintenance request
// @route POST /api/maintenance
const createRequest = async (req, res) => {
  try {
    const request = await MaintenanceRequest.create(req.body);
    res.status(201).json(request);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Get maintenance requests (filter: ?room=, ?status=, ?issueType=)
// @route GET /api/maintenance
const getRequests = async (req, res) => {
  try {
    const filter = {};
    if (req.query.room) filter.room = req.query.room;
    if (req.query.status) filter.status = req.query.status;
    if (req.query.issueType) filter.issueType = req.query.issueType;

    const requests = await MaintenanceRequest.find(filter)
      .populate("room", "roomNumber floor")
      .sort({ createdAt: -1 });
    res.json(requests);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Update a maintenance request (change status, resolvedDate, priority)
// @route PUT /api/maintenance/:id
const updateRequest = async (req, res) => {
  try {
    const updates = { ...req.body };
    if (updates.status === "resolved" && !updates.resolvedDate) {
      updates.resolvedDate = new Date();
    }
    const request = await MaintenanceRequest.findByIdAndUpdate(req.params.id, updates, {
      new: true,
      runValidators: true,
    });
    if (!request) return res.status(404).json({ message: "Maintenance request not found" });
    res.json(request);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Predict when a room is next likely to need maintenance.
//        Simple heuristic: looks at resolved requests for the room, averages
//        the time gap between consecutive issues, and projects that gap
//        forward from the most recent resolved date. Also flags issue types
//        that recur most often for that room (useful for preventive checks).
// @route GET /api/maintenance/predict/:roomId
const predictNextMaintenance = async (req, res) => {
  try {
    const { roomId } = req.params;
    const history = await MaintenanceRequest.find({ room: roomId, status: "resolved" }).sort({
      resolvedDate: 1,
    });

    if (history.length < 2) {
      return res.json({
        room: roomId,
        prediction: null,
        message: "Not enough resolved maintenance history yet for a reliable prediction (need at least 2 records).",
        totalRequestsLogged: history.length,
      });
    }

    // Average gap (in days) between consecutive resolved issues
    let totalGapDays = 0;
    for (let i = 1; i < history.length; i++) {
      const gap = (history[i].resolvedDate - history[i - 1].resolvedDate) / (1000 * 60 * 60 * 24);
      totalGapDays += gap;
    }
    const avgGapDays = totalGapDays / (history.length - 1);

    const lastResolved = history[history.length - 1].resolvedDate;
    const predictedNextDate = new Date(lastResolved.getTime() + avgGapDays * 24 * 60 * 60 * 1000);

    // Most frequent issue type for this room (likely recurring problem)
    const typeCounts = {};
    history.forEach((r) => {
      typeCounts[r.issueType] = (typeCounts[r.issueType] || 0) + 1;
    });
    const mostCommonIssue = Object.entries(typeCounts).sort((a, b) => b[1] - a[1])[0][0];

    res.json({
      room: roomId,
      totalRequestsLogged: history.length,
      averageGapBetweenIssuesDays: Math.round(avgGapDays),
      mostCommonIssueType: mostCommonIssue,
      predictedNextMaintenanceDate: predictedNextDate,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { createRequest, getRequests, updateRequest, predictNextMaintenance };
