const Notice = require("../models/Notice");

// @desc  Post a new notice
// @route POST /api/notices
const createNotice = async (req, res) => {
  try {
    const notice = await Notice.create({ ...req.body, postedBy: req.admin._id });
    res.status(201).json(notice);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Get all notices (auto-hides expired ones unless ?includeExpired=true)
// @route GET /api/notices
const getNotices = async (req, res) => {
  try {
    const filter = {};
    if (req.query.includeExpired !== "true") {
      filter.$or = [{ expiryDate: null }, { expiryDate: { $gte: new Date() } }];
    }
    const notices = await Notice.find(filter)
      .populate("postedBy", "name")
      .sort({ important: -1, createdAt: -1 });
    res.json(notices);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Update a notice
// @route PUT /api/notices/:id
const updateNotice = async (req, res) => {
  try {
    const notice = await Notice.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!notice) return res.status(404).json({ message: "Notice not found" });
    res.json(notice);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Delete a notice
// @route DELETE /api/notices/:id
const deleteNotice = async (req, res) => {
  try {
    const notice = await Notice.findByIdAndDelete(req.params.id);
    if (!notice) return res.status(404).json({ message: "Notice not found" });
    res.json({ message: "Notice removed" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { createNotice, getNotices, updateNotice, deleteNotice };
