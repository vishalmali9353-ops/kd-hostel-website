const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const {
  createNotice,
  getNotices,
  updateNotice,
  deleteNotice,
} = require("../controllers/noticeController");

// Anyone (students included) can read notices; only admins can post/edit/delete
router.route("/").get(getNotices).post(protect, createNotice);
router.route("/:id").put(protect, updateNotice).delete(protect, deleteNotice);

module.exports = router;
