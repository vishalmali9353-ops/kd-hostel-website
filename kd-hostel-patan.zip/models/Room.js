const mongoose = require("mongoose");

const roomSchema = new mongoose.Schema(
  {
    roomNumber: { type: String, required: true, unique: true },
    floor: { type: Number, required: true },
    type: {
      type: String,
      enum: ["single", "double", "triple", "dormitory"],
      default: "double",
    },
    capacity: { type: Number, required: true, default: 2 },
    occupied: { type: Number, default: 0 },
    rentPerMonth: { type: Number, required: true },
    status: {
      type: String,
      enum: ["available", "full", "maintenance"],
      default: "available",
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Room", roomSchema);
