const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const { autoAllocateRoom } = require("../controllers/roomAllocationController");

router.post("/:studentId", protect, autoAllocateRoom);

module.exports = router;
