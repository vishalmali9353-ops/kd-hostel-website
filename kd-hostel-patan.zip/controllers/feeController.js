const Fee = require("../models/Fee");

// @desc  Create a fee invoice for a student for a given month
// @route POST /api/fees
const createFeeInvoice = async (req, res) => {
  try {
    const { student, month, rentAmount = 0, messAmount = 0, otherCharges = 0, dueDate } = req.body;
    const totalAmount = Number(rentAmount) + Number(messAmount) + Number(otherCharges);

    const fee = await Fee.create({
      student,
      month,
      rentAmount,
      messAmount,
      otherCharges,
      totalAmount,
      dueDate,
    });
    res.status(201).json(fee);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Get all fee records (filter: ?student=, ?status=, ?month=)
// @route GET /api/fees
const getFees = async (req, res) => {
  try {
    const filter = {};
    if (req.query.student) filter.student = req.query.student;
    if (req.query.status) filter.status = req.query.status;
    if (req.query.month) filter.month = req.query.month;

    // Auto-flag overdue invoices that are past due date and still pending
    await Fee.updateMany(
      { status: "pending", dueDate: { $lt: new Date() } },
      { $set: { status: "overdue" } }
    );

    const fees = await Fee.find(filter).populate("student", "name email room").sort({ dueDate: 1 });
    res.json(fees);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Mark a fee invoice as paid
// @route PUT /api/fees/:id/pay
const payFee = async (req, res) => {
  try {
    const { method } = req.body;
    const fee = await Fee.findByIdAndUpdate(
      req.params.id,
      { status: "paid", paidOn: new Date(), method: method || "cash" },
      { new: true }
    );
    if (!fee) return res.status(404).json({ message: "Fee invoice not found" });
    res.json(fee);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Get all pending/overdue fees for one student (for their dashboard)
// @route GET /api/fees/due/:studentId
const getDueFees = async (req, res) => {
  try {
    const fees = await Fee.find({
      student: req.params.studentId,
      status: { $in: ["pending", "overdue"] },
    }).sort({ dueDate: 1 });
    const totalDue = fees.reduce((sum, f) => sum + f.totalAmount, 0);
    res.json({ totalDue, fees });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { createFeeInvoice, getFees, payFee, getDueFees };
