const Student = require("../models/Student");
const Room = require("../models/Room");
const Notice = require("../models/Notice");
const Complaint = require("../models/Complaint");

// @desc  Public dashboard/overview for the hostel home page
// @route GET /api/home
const getHomeOverview = async (req, res) => {
  try {
    const [totalStudents, totalRooms, availableRooms, openComplaints, notices] =
      await Promise.all([
        Student.countDocuments({ status: "active" }),
        Room.countDocuments(),
        Room.countDocuments({ status: "available" }),
        Complaint.countDocuments({ status: { $ne: "resolved" } }),
        Notice.find().sort({ createdAt: -1 }).limit(5),
      ]);

    res.json({
      hostelName: "KD Hostel Patan",
      stats: {
        totalStudents,
        totalRooms,
        availableRooms,
        openComplaints,
      },
      latestNotices: notices,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { getHomeOverview };
