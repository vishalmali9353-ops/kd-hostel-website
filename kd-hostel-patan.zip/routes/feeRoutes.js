const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const { protectStudent } = require("../middleware/studentAuthMiddleware");
const { createFeeInvoice, getFees, payFee, getDueFees } = require("../controllers/feeController");

router.route("/").post(protect, createFeeInvoice).get(protect, getFees);
router.put("/:id/pay", protect, payFee);
router.get("/due/:studentId", protectStudent, getDueFees);

module.exports = router;
