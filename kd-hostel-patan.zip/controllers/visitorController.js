const Visitor = require("../models/Visitor");

// @desc  Log a visitor check-in at the gate
// @route POST /api/visitors
const checkInVisitor = async (req, res) => {
  try {
    const visitor = await Visitor.create({
      ...req.body,
      approvedBy: req.admin._id,
      status: "checked_in",
      checkInTime: new Date(),
    });
    res.status(201).json(visitor);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Mark a visitor as checked out
// @route PUT /api/visitors/:id/checkout
const checkOutVisitor = async (req, res) => {
  try {
    const visitor = await Visitor.findById(req.params.id);
    if (!visitor) return res.status(404).json({ message: "Visitor record not found" });

    visitor.status = "checked_out";
    visitor.checkOutTime = new Date();
    await visitor.save();

    res.json(visitor);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Get all visitors (filter: ?status=checked_in, ?student=id)
// @route GET /api/visitors
const getVisitors = async (req, res) => {
  try {
    const filter = {};
    if (req.query.status) filter.status = req.query.status;
    if (req.query.student) filter.studentVisited = req.query.student;

    const visitors = await Visitor.find(filter)
      .populate("studentVisited", "name room")
      .sort({ checkInTime: -1 });
    res.json(visitors);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { checkInVisitor, checkOutVisitor, getVisitors };
