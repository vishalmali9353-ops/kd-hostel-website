const mongoose = require("mongoose");

const paymentSchema = new mongoose.Schema(
  {
    student: { type: mongoose.Schema.Types.ObjectId, ref: "Student", required: true },
    amount: { type: Number, required: true },
    month: { type: String, required: true }, // e.g. "August 2026"
    paymentDate: { type: Date, default: Date.now },
    status: {
      type: String,
      enum: ["paid", "pending", "overdue"],
      default: "paid",
    },
    method: {
      type: String,
      enum: ["cash", "upi", "card", "bank_transfer"],
      default: "cash",
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Payment", paymentSchema);
