const mongoose = require("mongoose");

const maintenanceRequestSchema = new mongoose.Schema(
  {
    room: { type: mongoose.Schema.Types.ObjectId, ref: "Room", required: true },
    issueType: {
      type: String,
      enum: ["electrical", "plumbing", "furniture", "appliance", "civil", "other"],
      required: true,
    },
    description: { type: String, required: true },
    priority: { type: String, enum: ["low", "medium", "high"], default: "medium" },
    status: { type: String, enum: ["open", "in_progress", "resolved"], default: "open" },
    reportedDate: { type: Date, default: Date.now },
    resolvedDate: { type: Date, default: null },
  },
  { timestamps: true }
);

module.exports = mongoose.model("MaintenanceRequest", maintenanceRequestSchema);
