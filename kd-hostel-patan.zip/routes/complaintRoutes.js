const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const { protectStudent } = require("../middleware/studentAuthMiddleware");
const {
  createComplaint,
  getComplaints,
  updateComplaint,
  deleteComplaint,
} = require("../controllers/complaintController");

// Students raise complaints themselves; admins view/manage all of them
router.post("/", protectStudent, createComplaint);
router.get("/", protect, getComplaints);
router.route("/:id").put(protect, updateComplaint).delete(protect, deleteComplaint);

module.exports = router;
