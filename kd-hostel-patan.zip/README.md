# KD Hostel Patan — Backend

Full backend API for **KD Hostel Patan**, built with **Node.js**, **Express**, and **MongoDB (Mongoose)**.
All 11 modules are implemented as **separate model / controller / route files**, so each team member can
work on their own module independently.

---

## 1. Module ownership & structure

| # | Module                    | Owner   | Model(s)                          | Controller                    | Routes (base path)      |
|---|----------------------------|---------|-------------------------------------|--------------------------------|---------------------------|
| 1 | Home Page                  | vishal  | (reads Student/Room/Notice/Complaint) | `homeController.js`           | `/api/home`               |
| 2 | Notice                     | —       | `Notice.js`                         | `noticeController.js`          | `/api/notices`             |
| 3 | Student Registration       | —       | `Student.js`                        | `studentAuthController.js`, `studentController.js` | `/api/student-auth`, `/api/students` |
| 4 | Smart Room Allocation       | —       | `Room.js`, `Student.js`             | `roomAllocationController.js`  | `/api/room-allocation`     |
| 5 | Visitor Management          | nilesh  | `Visitor.js`                        | `visitorController.js`         | `/api/visitors`            |
| 6 | Mess Management             | nilesh  | `MessMenu.js`, `MessFeedback.js`    | `messController.js`            | `/api/mess`                |
| 7 | Complaint Management        | nilesh  | `Complaint.js`                      | `complaintController.js`       | `/api/complaints`          |
| 8 | Security & Surveillance     | —       | `SecurityLog.js`                    | `securityController.js`        | `/api/security`            |
| 9 | Fee Management              | —       | `Fee.js`                            | `feeController.js`             | `/api/fees`                |
| 10| Maintenance Prediction      | —       | `MaintenanceRequest.js`             | `maintenanceController.js`     | `/api/maintenance`         |
| 11| 24/7 Student Support        | —       | `SupportTicket.js`                  | `supportController.js`         | `/api/support`             |

Plus supporting infrastructure: `Admin.js` (wardens/admins) and `Payment.js` (legacy — superseded by the
new `Fee.js` module, kept for backward compatibility).

---

## 2. Full project structure

```
kd-hostel-patan/
├── config/
│   └── db.js
├── middleware/
│   ├── authMiddleware.js          # protects admin/warden routes (JWT)
│   └── studentAuthMiddleware.js   # protects student routes (JWT)
├── models/
│   ├── Admin.js
│   ├── Student.js
│   ├── Room.js
│   ├── Notice.js
│   ├── Visitor.js
│   ├── MessMenu.js
│   ├── MessFeedback.js
│   ├── Complaint.js
│   ├── SecurityLog.js
│   ├── Fee.js
│   ├── Payment.js
│   ├── MaintenanceRequest.js
│   └── SupportTicket.js
├── controllers/
│   ├── authController.js
│   ├── homeController.js
│   ├── noticeController.js
│   ├── studentAuthController.js
│   ├── studentController.js
│   ├── roomAllocationController.js
│   ├── roomController.js
│   ├── visitorController.js
│   ├── messController.js
│   ├── complaintController.js
│   ├── securityController.js
│   ├── feeController.js
│   ├── paymentController.js
│   ├── maintenanceController.js
│   └── supportController.js
├── routes/
│   ├── authRoutes.js
│   ├── homeRoutes.js
│   ├── noticeRoutes.js
│   ├── studentAuthRoutes.js
│   ├── studentRoutes.js
│   ├── roomAllocationRoutes.js
│   ├── roomRoutes.js
│   ├── visitorRoutes.js
│   ├── messRoutes.js
│   ├── complaintRoutes.js
│   ├── securityRoutes.js
│   ├── feeRoutes.js
│   ├── paymentRoutes.js
│   ├── maintenanceRoutes.js
│   └── supportRoutes.js
├── .env.example
├── .gitignore
├── package.json
├── server.js
└── README.md
```

---

## 3. Two types of accounts

- **Admin / Warden** (`Admin.js`) — manages the whole hostel: rooms, notices, fees, security, mess menu,
  visitor approval, maintenance, and responds to student support tickets.
  Auth routes: `/api/auth/register`, `/api/auth/login`. Protected routes use header
  `Authorization: Bearer <admin_token>`.

- **Student** (`Student.js`) — registers themselves, views notices/mess menu, raises complaints & support
  tickets, gives mess feedback, checks their own fee dues.
  Auth routes: `/api/student-auth/register`, `/api/student-auth/login`. Protected routes use header
  `Authorization: Bearer <student_token>`.

---

## 4. Prerequisites

1. **Node.js** (v18+) — https://nodejs.org
2. **MongoDB** — local (https://www.mongodb.com/try/download/community) or free cloud **MongoDB Atlas**
   (https://www.mongodb.com/cloud/atlas/register)
3. **Git** — https://git-scm.com/downloads
4. A **GitHub** account — https://github.com
5. (Optional) **Postman** to test the API

---

## 5. Step-by-step: run it locally

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# then edit .env: set MONGO_URI and JWT_SECRET

# 3. Start MongoDB if running it locally
mongod

# 4. Run the server (auto-restart on changes)
npm run dev
# or for production:
npm start
```

You should see:
```
MongoDB connected: <host>
KD Hostel Patan server running on port 5000
```

Visit `http://localhost:5000/api/home` to see the public hostel overview.

---

## 6. API quick reference (by module)

### 1. Home Page — `/api/home`
| Method | Endpoint | Access | Description |
|--------|-----------|--------|--------------|
| GET | `/api/home` | Public | Hostel stats + latest notices, for the landing/home page |

### 2. Notice — `/api/notices`
| Method | Endpoint | Access | Description |
|--------|-----------|--------|--------------|
| GET | `/api/notices` | Public | List active notices |
| POST | `/api/notices` | Admin | Post a notice `{title, message, audience, important, expiryDate}` |
| PUT | `/api/notices/:id` | Admin | Update a notice |
| DELETE | `/api/notices/:id` | Admin | Delete a notice |

### 3. Student Registration — `/api/student-auth` + `/api/students`
| Method | Endpoint | Access | Description |
|--------|-----------|--------|--------------|
| POST | `/api/student-auth/register` | Public | Student self-registers `{name, email, password, phone, ...}` |
| POST | `/api/student-auth/login` | Public | Student login |
| GET | `/api/student-auth/me` | Student | Get own profile |
| POST/GET/PUT/DELETE | `/api/students` | Admin | Admin-side admission & management |

### 4. Smart Room Allocation — `/api/room-allocation`
| Method | Endpoint | Access | Description |
|--------|-----------|--------|--------------|
| POST | `/api/room-allocation/:studentId` | Admin | Auto-assigns the best available room. Body (optional): `{preferredType, preferredFloor}`. Picks the least-occupied matching room, falls back gracefully if no exact match. |

### 5. Visitor Management — `/api/visitors` (nilesh)
| Method | Endpoint | Access | Description |
|--------|-----------|--------|--------------|
| POST | `/api/visitors` | Admin | Check in a visitor `{name, phone, purpose, studentVisited, idProofType}` |
| PUT | `/api/visitors/:id/checkout` | Admin | Check out a visitor |
| GET | `/api/visitors` | Admin | List visitors (filter `?status=`, `?student=`) |

### 6. Mess Management — `/api/mess` (nilesh)
| Method | Endpoint | Access | Description |
|--------|-----------|--------|--------------|
| POST | `/api/mess/menu` | Admin | Set/update a day's menu `{day, breakfast, lunch, dinner}` |
| GET | `/api/mess/menu` | Public | View weekly menu (or `?day=Monday`) |
| POST | `/api/mess/feedback` | Student | Submit feedback `{meal, rating, comment}` |
| GET | `/api/mess/feedback` | Admin | View feedback + average rating (filter `?meal=`) |

### 7. Complaint Management — `/api/complaints` (nilesh)
| Method | Endpoint | Access | Description |
|--------|-----------|--------|--------------|
| POST | `/api/complaints` | Student | Raise a complaint `{subject, description, room}` |
| GET | `/api/complaints` | Admin | View all (filter `?status=`, `?student=`) |
| PUT | `/api/complaints/:id` | Admin | Update status |
| DELETE | `/api/complaints/:id` | Admin | Delete |

### 8. Security & Surveillance — `/api/security`
| Method | Endpoint | Access | Description |
|--------|-----------|--------|--------------|
| POST | `/api/security` | Admin | Log entry `{type: gate_entry/gate_exit/incident/camera_alert, person, description, cameraZone, severity}` |
| GET | `/api/security` | Admin | List logs (filter `?type=`, `?severity=`, `?resolved=`) |
| PUT | `/api/security/:id` | Admin | Update/resolve a log |

### 9. Fee Management — `/api/fees`
| Method | Endpoint | Access | Description |
|--------|-----------|--------|--------------|
| POST | `/api/fees` | Admin | Create an invoice `{student, month, rentAmount, messAmount, otherCharges, dueDate}` |
| GET | `/api/fees` | Admin | List fees (filter `?student=`, `?status=`, `?month=`); auto-flags overdue |
| PUT | `/api/fees/:id/pay` | Admin | Mark an invoice paid `{method}` |
| GET | `/api/fees/due/:studentId` | Student | Student's own pending/overdue dues |

### 10. Maintenance Prediction — `/api/maintenance`
| Method | Endpoint | Access | Description |
|--------|-----------|--------|--------------|
| POST | `/api/maintenance` | Admin | Log an issue `{room, issueType, description, priority}` |
| GET | `/api/maintenance` | Admin | List requests (filter `?room=`, `?status=`, `?issueType=`) |
| PUT | `/api/maintenance/:id` | Admin | Update status/priority |
| GET | `/api/maintenance/predict/:roomId` | Admin | Predicts the next likely maintenance date for a room, based on the average gap between past resolved issues, plus the most common recurring issue type |

### 11. 24/7 Student Support — `/api/support`
| Method | Endpoint | Access | Description |
|--------|-----------|--------|--------------|
| POST | `/api/support` | Student | Raise a ticket `{category: technical/hostel/academic/emergency/other, message, priority}` — emergency tickets auto-escalate to "urgent" |
| GET | `/api/support/my` | Student | View own tickets |
| GET | `/api/support` | Admin | View all tickets, sorted urgent-first (filter `?status=`, `?priority=`, `?category=`) |
| PUT | `/api/support/:id` | Admin | Respond & update status |

All admin routes need header `Authorization: Bearer <admin_token>` (from `/api/auth/login`).
All student routes need header `Authorization: Bearer <student_token>` (from `/api/student-auth/login`).

---

## 7. Step-by-step: push to GitHub

```bash
# 1. Create a new repo at https://github.com/new named "kd-hostel-patan" (leave it empty, no README)

# 2. From the project folder:
git init
git add .
git commit -m "Initial commit: KD Hostel Patan backend - all 11 modules"
git branch -M main
git remote add origin https://github.com/<your-username>/kd-hostel-patan.git
git push -u origin main
```
`.env` is excluded automatically via `.gitignore` — your secrets stay local.

For future changes:
```bash
git add .
git commit -m "Describe your change"
git push
```

---

## 8. Deploying (optional)

- **Render** (https://render.com) or **Railway** (https://railway.app) — connect your GitHub repo, set
  `PORT`, `MONGO_URI`, `JWT_SECRET`, `JWT_EXPIRES_IN` in the dashboard, auto-deploys on every push.
- Use **MongoDB Atlas** (free tier) for the database so it's reachable from the deployed server.

---

## 9. Notes for the team

- Each module's model/controller/route trio is self-contained — work on your module's files without
  touching anyone else's; only `server.js` needs a one-line addition to wire in a brand-new module.
- Passwords (Admin and Student) are bcrypt-hashed — never stored in plain text.
- `Payment.js`/`paymentController.js`/`paymentRoutes.js` are kept from the earlier version for backward
  compatibility; new fee work should use the `Fee` module instead.
- This is backend/API only — pair it with a frontend (React, plain HTML/JS, or a mobile app) that calls
  these endpoints, or test everything directly with Postman first.
