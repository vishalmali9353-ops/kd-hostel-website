const mongoose = require("mongoose");

const visitorSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    phone: { type: String, required: true },
    purpose: { type: String, required: true },
    studentVisited: { type: mongoose.Schema.Types.ObjectId, ref: "Student", required: true },
    idProofType: {
      type: String,
      enum: ["aadhar", "pan", "driving_license", "voter_id", "other"],
      default: "aadhar",
    },
    checkInTime: { type: Date, default: Date.now },
    checkOutTime: { type: Date, default: null },
    status: { type: String, enum: ["checked_in", "checked_out"], default: "checked_in" },
    approvedBy: { type: mongoose.Schema.Types.ObjectId, ref: "Admin" },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Visitor", visitorSchema);
