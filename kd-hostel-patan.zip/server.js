const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");
const connectDB = require("./config/db");

dotenv.config();
connectDB();

const app = express();

app.use(cors());
app.use(express.json());

// Root route
app.get("/", (req, res) => {
  res.json({ message: "KD Hostel Patan API is running" });
});

/* ===================== MODULE ROUTES =====================
   1. Home Page              -> /api/home            (vishal)
   2. Notice                 -> /api/notices
   3. Student Registration   -> /api/student-auth
      (admin-side student admin) -> /api/students
   4. Smart Room Allocation  -> /api/room-allocation
      (basic room CRUD)      -> /api/rooms
   5. Visitor Management     -> /api/visitors         (nilesh)
   6. Mess Management        -> /api/mess             (nilesh)
   7. Complaint Management   -> /api/complaints       (nilesh)
   8. Security & Surveillance-> /api/security
   9. Fee Management         -> /api/fees
   10. Maintenance Prediction-> /api/maintenance
   11. 24/7 Student Support  -> /api/support
   ============================================================ */

app.use("/api/auth", require("./routes/authRoutes")); // admin/warden auth
app.use("/api/home", require("./routes/homeRoutes"));
app.use("/api/notices", require("./routes/noticeRoutes"));
app.use("/api/student-auth", require("./routes/studentAuthRoutes"));
app.use("/api/students", require("./routes/studentRoutes"));
app.use("/api/room-allocation", require("./routes/roomAllocationRoutes"));
app.use("/api/rooms", require("./routes/roomRoutes"));
app.use("/api/visitors", require("./routes/visitorRoutes"));
app.use("/api/mess", require("./routes/messRoutes"));
app.use("/api/complaints", require("./routes/complaintRoutes"));
app.use("/api/security", require("./routes/securityRoutes"));
app.use("/api/fees", require("./routes/feeRoutes"));
app.use("/api/maintenance", require("./routes/maintenanceRoutes"));
app.use("/api/support", require("./routes/supportRoutes"));

// 404 handler
app.use((req, res) => {
  res.status(404).json({ message: "Route not found" });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: "Something went wrong on the server" });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`KD Hostel Patan server running on port ${PORT}`);
});
