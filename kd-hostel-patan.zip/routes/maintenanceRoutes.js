const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const {
  createRequest,
  getRequests,
  updateRequest,
  predictNextMaintenance,
} = require("../controllers/maintenanceController");

router.route("/").post(protect, createRequest).get(protect, getRequests);
router.get("/predict/:roomId", protect, predictNextMaintenance);
router.put("/:id", protect, updateRequest);

module.exports = router;
