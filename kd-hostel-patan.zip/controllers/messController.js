const MessMenu = require("../models/MessMenu");
const MessFeedback = require("../models/MessFeedback");

// @desc  Set/update the menu for a day (creates if not exists)
// @route POST /api/mess/menu
const setMenu = async (req, res) => {
  try {
    const { day, breakfast, lunch, dinner } = req.body;
    const menu = await MessMenu.findOneAndUpdate(
      { day },
      { day, breakfast, lunch, dinner, updatedBy: req.admin._id },
      { new: true, upsert: true, runValidators: true }
    );
    res.status(201).json(menu);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Get full week menu (or one day via ?day=Monday)
// @route GET /api/mess/menu
const getMenu = async (req, res) => {
  try {
    const filter = req.query.day ? { day: req.query.day } : {};
    const menu = await MessMenu.find(filter);
    res.json(menu);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Student submits mess feedback/rating
// @route POST /api/mess/feedback
const submitFeedback = async (req, res) => {
  try {
    const feedback = await MessFeedback.create({ ...req.body, student: req.student._id });
    res.status(201).json(feedback);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Get mess feedback (admin view, filter: ?meal=lunch)
// @route GET /api/mess/feedback
const getFeedback = async (req, res) => {
  try {
    const filter = {};
    if (req.query.meal) filter.meal = req.query.meal;

    const feedback = await MessFeedback.find(filter)
      .populate("student", "name room")
      .sort({ createdAt: -1 });

    const avgRating =
      feedback.length > 0
        ? (feedback.reduce((sum, f) => sum + f.rating, 0) / feedback.length).toFixed(2)
        : null;

    res.json({ averageRating: avgRating, count: feedback.length, feedback });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { setMenu, getMenu, submitFeedback, getFeedback };
