const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const { protectStudent } = require("../middleware/studentAuthMiddleware");
const { setMenu, getMenu, submitFeedback, getFeedback } = require("../controllers/messController");

router.route("/menu").post(protect, setMenu).get(getMenu); // menu is public to view
router.post("/feedback", protectStudent, submitFeedback);
router.get("/feedback", protect, getFeedback);

module.exports = router;
