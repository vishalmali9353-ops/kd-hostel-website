const mongoose = require("mongoose");

const feeSchema = new mongoose.Schema(
  {
    student: { type: mongoose.Schema.Types.ObjectId, ref: "Student", required: true },
    month: { type: String, required: true }, // e.g. "August 2026"
    rentAmount: { type: Number, required: true, default: 0 },
    messAmount: { type: Number, required: true, default: 0 },
    otherCharges: { type: Number, default: 0 },
    totalAmount: { type: Number, required: true },
    dueDate: { type: Date, required: true },
    paidOn: { type: Date, default: null },
    method: {
      type: String,
      enum: ["cash", "upi", "card", "bank_transfer", null],
      default: null,
    },
    status: {
      type: String,
      enum: ["pending", "paid", "overdue"],
      default: "pending",
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Fee", feeSchema);
