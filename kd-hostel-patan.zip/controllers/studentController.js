const Student = require("../models/Student");
const Room = require("../models/Room");

// @desc  Register/admit a new student and (optionally) assign a room
// @route POST /api/students
const createStudent = async (req, res) => {
  try {
    const { name, email, password, phone, guardianName, guardianPhone, course, roomId } = req.body;

    const existing = await Student.findOne({ email });
    if (existing) {
      return res.status(400).json({ message: "Student already exists with this email" });
    }

    let room = null;
    if (roomId) {
      room = await Room.findById(roomId);
      if (!room) return res.status(404).json({ message: "Room not found" });
      if (room.occupied >= room.capacity) {
        return res.status(400).json({ message: "Room is already full" });
      }
    }

    const student = await Student.create({
      name,
      email,
      password,
      phone,
      guardianName,
      guardianPhone,
      course,
      room: room ? room._id : null,
    });

    if (room) {
      room.occupied += 1;
      room.status = room.occupied >= room.capacity ? "full" : "available";
      await room.save();
    }

    res.status(201).json(student);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Get all students
// @route GET /api/students
const getStudents = async (req, res) => {
  try {
    const students = await Student.find().populate("room", "roomNumber floor type").select("-password");
    res.json(students);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Get single student
// @route GET /api/students/:id
const getStudentById = async (req, res) => {
  try {
    const student = await Student.findById(req.params.id).populate("room").select("-password");
    if (!student) return res.status(404).json({ message: "Student not found" });
    res.json(student);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Update student
// @route PUT /api/students/:id
const updateStudent = async (req, res) => {
  try {
    const updates = { ...req.body };
    delete updates.password; // password changes should go through a dedicated route

    const student = await Student.findByIdAndUpdate(req.params.id, updates, {
      new: true,
      runValidators: true,
    }).select("-password");

    if (!student) return res.status(404).json({ message: "Student not found" });
    res.json(student);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Vacate / remove a student and free their room
// @route DELETE /api/students/:id
const deleteStudent = async (req, res) => {
  try {
    const student = await Student.findById(req.params.id);
    if (!student) return res.status(404).json({ message: "Student not found" });

    if (student.room) {
      const room = await Room.findById(student.room);
      if (room) {
        room.occupied = Math.max(0, room.occupied - 1);
        room.status = "available";
        await room.save();
      }
    }

    await student.deleteOne();
    res.json({ message: "Student removed" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { createStudent, getStudents, getStudentById, updateStudent, deleteStudent };
