const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const { checkInVisitor, checkOutVisitor, getVisitors } = require("../controllers/visitorController");

router.route("/").post(protect, checkInVisitor).get(protect, getVisitors);
router.put("/:id/checkout", protect, checkOutVisitor);

module.exports = router;
