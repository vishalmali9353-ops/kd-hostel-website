const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const { createLog, getLogs, updateLog } = require("../controllers/securityController");

router.route("/").post(protect, createLog).get(protect, getLogs);
router.put("/:id", protect, updateLog);

module.exports = router;
