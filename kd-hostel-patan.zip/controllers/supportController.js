const SupportTicket = require("../models/SupportTicket");

// @desc  Student raises a 24/7 support ticket (technical/hostel/academic/emergency)
// @route POST /api/support
const createTicket = async (req, res) => {
  try {
    const { category, message, priority } = req.body;
    // Emergency tickets are auto-flagged urgent so they surface first for staff
    const finalPriority = category === "emergency" ? "urgent" : priority || "medium";

    const ticket = await SupportTicket.create({
      student: req.student._id,
      category,
      message,
      priority: finalPriority,
    });
    res.status(201).json(ticket);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Get all support tickets (admin) - filter: ?status=, ?priority=, ?category=
// @route GET /api/support
const getTickets = async (req, res) => {
  try {
    const filter = {};
    if (req.query.status) filter.status = req.query.status;
    if (req.query.priority) filter.priority = req.query.priority;
    if (req.query.category) filter.category = req.query.category;

    // Urgent/open tickets surface first for round-the-clock response
    const tickets = await SupportTicket.find(filter)
      .populate("student", "name email room phone")
      .sort({ priority: -1, createdAt: 1 });
    res.json(tickets);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Student views their own tickets
// @route GET /api/support/my
const getMyTickets = async (req, res) => {
  try {
    const tickets = await SupportTicket.find({ student: req.student._id }).sort({ createdAt: -1 });
    res.json(tickets);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Admin/warden responds to and updates a ticket
// @route PUT /api/support/:id
const respondTicket = async (req, res) => {
  try {
    const { response, status } = req.body;
    const ticket = await SupportTicket.findByIdAndUpdate(
      req.params.id,
      { response, status, respondedBy: req.admin._id },
      { new: true, runValidators: true }
    );
    if (!ticket) return res.status(404).json({ message: "Support ticket not found" });
    res.json(ticket);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { createTicket, getTickets, getMyTickets, respondTicket };
