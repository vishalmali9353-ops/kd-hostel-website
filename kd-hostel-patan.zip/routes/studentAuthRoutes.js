const express = require("express");
const router = express.Router();
const { protectStudent } = require("../middleware/studentAuthMiddleware");
const {
  registerStudent,
  loginStudent,
  getMyProfile,
} = require("../controllers/studentAuthController");

router.post("/register", registerStudent);
router.post("/login", loginStudent);
router.get("/me", protectStudent, getMyProfile);

module.exports = router;
