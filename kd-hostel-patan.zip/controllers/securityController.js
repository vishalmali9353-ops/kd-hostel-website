const SecurityLog = require("../models/SecurityLog");

// @desc  Create a security log entry (gate entry/exit, incident, camera alert)
// @route POST /api/security
const createLog = async (req, res) => {
  try {
    const log = await SecurityLog.create({ ...req.body, reportedBy: req.admin._id });
    res.status(201).json(log);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Get security logs (filter: ?type=, ?severity=, ?resolved=true/false)
// @route GET /api/security
const getLogs = async (req, res) => {
  try {
    const filter = {};
    if (req.query.type) filter.type = req.query.type;
    if (req.query.severity) filter.severity = req.query.severity;
    if (req.query.resolved !== undefined) filter.resolved = req.query.resolved === "true";

    const logs = await SecurityLog.find(filter)
      .populate("studentRef", "name room")
      .sort({ createdAt: -1 });
    res.json(logs);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Mark a security incident as resolved / update it
// @route PUT /api/security/:id
const updateLog = async (req, res) => {
  try {
    const log = await SecurityLog.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!log) return res.status(404).json({ message: "Security log not found" });
    res.json(log);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { createLog, getLogs, updateLog };
