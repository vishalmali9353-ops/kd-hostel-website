const mongoose = require("mongoose");

const messFeedbackSchema = new mongoose.Schema(
  {
    student: { type: mongoose.Schema.Types.ObjectId, ref: "Student", required: true },
    date: { type: Date, default: Date.now },
    meal: { type: String, enum: ["breakfast", "lunch", "dinner"], required: true },
    rating: { type: Number, min: 1, max: 5, required: true },
    comment: { type: String },
  },
  { timestamps: true }
);

module.exports = mongoose.model("MessFeedback", messFeedbackSchema);
