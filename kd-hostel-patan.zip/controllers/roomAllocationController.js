const Room = require("../models/Room");
const Student = require("../models/Student");

// @desc  Smartly allocate the best available room to a student based on
//        preferences (room type, floor) and current occupancy load.
//        Picks the room with matching type/floor that has the FEWEST
//        occupants first (spreads students evenly), falling back to any
//        available room if no exact preference match exists.
// @route POST /api/room-allocation/:studentId
const autoAllocateRoom = async (req, res) => {
  try {
    const { studentId } = req.params;
    const { preferredType, preferredFloor } = req.body; // both optional

    const student = await Student.findById(studentId);
    if (!student) return res.status(404).json({ message: "Student not found" });
    if (student.room) {
      return res.status(400).json({ message: "Student already has a room assigned" });
    }

    // Build query: room must have space left
    const baseQuery = { $expr: { $lt: ["$occupied", "$capacity"] } };

    // Try to find the best match first (matches type + floor)
    let candidates = await Room.find({
      ...baseQuery,
      ...(preferredType ? { type: preferredType } : {}),
      ...(preferredFloor !== undefined ? { floor: preferredFloor } : {}),
    }).sort({ occupied: 1 });

    // Fallback: relax floor preference, keep type
    if (candidates.length === 0 && preferredType) {
      candidates = await Room.find({ ...baseQuery, type: preferredType }).sort({ occupied: 1 });
    }

    // Fallback: any available room at all
    if (candidates.length === 0) {
      candidates = await Room.find(baseQuery).sort({ occupied: 1 });
    }

    if (candidates.length === 0) {
      return res.status(404).json({ message: "No rooms available right now" });
    }

    const room = candidates[0];
    room.occupied += 1;
    room.status = room.occupied >= room.capacity ? "full" : "available";
    await room.save();

    student.room = room._id;
    await student.save();

    res.json({
      message: "Room allocated successfully",
      student: { _id: student._id, name: student.name },
      room,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { autoAllocateRoom };
