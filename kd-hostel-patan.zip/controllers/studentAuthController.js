const jwt = require("jsonwebtoken");
const Student = require("../models/Student");

const generateToken = (id) => {
  return jwt.sign({ id, type: "student" }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || "7d",
  });
};

// @desc  Student self-registration (public). Student is created as "pending"
//        until a room is assigned via the Smart Room Allocation module.
// @route POST /api/student-auth/register
const registerStudent = async (req, res) => {
  try {
    const { name, email, password, phone, guardianName, guardianPhone, course } = req.body;

    if (!name || !email || !password || !phone) {
      return res.status(400).json({ message: "Please provide name, email, password and phone" });
    }

    const existing = await Student.findOne({ email });
    if (existing) {
      return res.status(400).json({ message: "An account with this email already exists" });
    }

    const student = await Student.create({
      name,
      email,
      password,
      phone,
      guardianName,
      guardianPhone,
      course,
    });

    res.status(201).json({
      _id: student._id,
      name: student.name,
      email: student.email,
      room: student.room,
      token: generateToken(student._id),
      message: "Registration successful. Room will be assigned shortly.",
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Student login
// @route POST /api/student-auth/login
const loginStudent = async (req, res) => {
  try {
    const { email, password } = req.body;

    const student = await Student.findOne({ email });
    if (!student || !(await student.matchPassword(password))) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    res.json({
      _id: student._id,
      name: student.name,
      email: student.email,
      room: student.room,
      token: generateToken(student._id),
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Get logged-in student's own profile
// @route GET /api/student-auth/me
const getMyProfile = async (req, res) => {
  try {
    const student = await Student.findById(req.student._id).populate("room").select("-password");
    res.json(student);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { registerStudent, loginStudent, getMyProfile };
