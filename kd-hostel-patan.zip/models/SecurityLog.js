const mongoose = require("mongoose");

const securityLogSchema = new mongoose.Schema(
  {
    type: {
      type: String,
      enum: ["gate_entry", "gate_exit", "incident", "camera_alert"],
      required: true,
    },
    person: { type: String, required: true }, // name of student/staff/visitor involved
    studentRef: { type: mongoose.Schema.Types.ObjectId, ref: "Student", default: null },
    description: { type: String, required: true },
    cameraZone: { type: String }, // e.g. "Main Gate", "Block A Corridor"
    severity: { type: String, enum: ["low", "medium", "high"], default: "low" },
    reportedBy: { type: mongoose.Schema.Types.ObjectId, ref: "Admin", required: true },
    resolved: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model("SecurityLog", securityLogSchema);
