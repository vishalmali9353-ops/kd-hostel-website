const Complaint = require("../models/Complaint");

// @desc  Raise a complaint (student, logged in)
// @route POST /api/complaints
const createComplaint = async (req, res) => {
  try {
    const { subject, description, room } = req.body;
    const complaint = await Complaint.create({
      student: req.student._id,
      room: room || req.student.room,
      subject,
      description,
    });
    res.status(201).json(complaint);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Get all complaints (admin) - filter: ?status=, ?student=
// @route GET /api/complaints
const getComplaints = async (req, res) => {
  try {
    const filter = {};
    if (req.query.status) filter.status = req.query.status;
    if (req.query.student) filter.student = req.query.student;

    const complaints = await Complaint.find(filter)
      .populate("student", "name email")
      .populate("room", "roomNumber")
      .sort({ createdAt: -1 });
    res.json(complaints);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Update complaint status (admin)
// @route PUT /api/complaints/:id
const updateComplaint = async (req, res) => {
  try {
    const complaint = await Complaint.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!complaint) return res.status(404).json({ message: "Complaint not found" });
    res.json(complaint);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc  Delete complaint (admin)
// @route DELETE /api/complaints/:id
const deleteComplaint = async (req, res) => {
  try {
    const complaint = await Complaint.findByIdAndDelete(req.params.id);
    if (!complaint) return res.status(404).json({ message: "Complaint not found" });
    res.json({ message: "Complaint removed" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { createComplaint, getComplaints, updateComplaint, deleteComplaint };
